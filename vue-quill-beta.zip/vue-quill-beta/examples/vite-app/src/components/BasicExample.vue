<script setup lang="ts">
</script>

<template>
  <QuillEditor class="basic-example" theme="snow" />
</template>

<style scoped>
.basic-example {
  height: 600px;
}
</style>
