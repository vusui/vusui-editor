<script setup lang="ts">
import ContentTypesExample from '@/components/ContentTypesExample.vue'
</script>

<template>
  <main>
    <ContentTypesExample />
  </main>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
