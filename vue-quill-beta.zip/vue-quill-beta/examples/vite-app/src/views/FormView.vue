<script setup lang="ts">
import FormExample from '@/components/FormExample.vue'
</script>

<template>
  <main>
    <FormExample />
  </main>
</template>
