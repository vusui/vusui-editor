<script setup lang="ts">
import BasicExample from '@/components/BasicExample.vue'
</script>

<template>
  <main>
    <BasicExample />
  </main>
</template>
