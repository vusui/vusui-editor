/// <reference types="vite/client" />

declare module 'vue3-highlightjs'
