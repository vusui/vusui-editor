# [1.0.0-beta.8](https://github.com/vueup/vue-quill/compare/v1.0.0-beta.7...v1.0.0-beta.8) (2022-02-17)


### Bug Fixes

* :bug: remove unsupported workspaces (semantic-release) ([10a552b](https://github.com/vueup/vue-quill/commit/10a552b79fdda00b1e81f9795232d665f2805cd1))
* try to fix semantic-release/npm ([3cc858a](https://github.com/vueup/vue-quill/commit/3cc858ab5c10da7539a05bdd512d17907bc32f83))
